#ifndef DisplayShield_h
#define DisplayShield_h

#include <Arduino.h>
#include <inttypes.h>

#define CWTL 0xFF // can't write the letter
/* Segment byte maps for numbers 0 to 9 */
const byte SEGMENT_MAP[] = {0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0X80,0X90};
/* Byte maps to select digit 1 to 4 */
const byte SEGMENT_SELECT[] = {0xF1,0xF2,0xF4,0xF8};
/* Segment_alpha byte maps for letters A to Z */
const byte SEGMENT_MAP_ALPHA[] = {0x88, 0x80, 0xC6, 0xC0, 0x86, 0x8E, 0x82, 0x89, 0xF9, 0xA1, CWTL, 0xC7, 0xAB, 0xAB, 0xC0, 0x8C, 0x98, 0x88, 0xAA, 0xCE, 0xE3, 0xC1, CWTL, CWTL, 0x99, 0xAA};

class DisplayShield {
    public:
        DisplayShield(int ld, int cd, int dd);
        void WriteNumberToSegment(byte Segment, byte Value);
        void WriteBigNum(int n);
        void WriteLetterToSegment(byte Segment, char c);
    private:
        int LATCH_DIO; 
        int CLK_DIO; 
        int DATA_DIO; 
};

#endif




//https://www.electroschematics.com/getting-started-with-the-arduino-multifunction-shield/
