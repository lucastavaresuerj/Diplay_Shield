#include <Arduino.h>
#include <inttypes.h>
#include "DisplayShield.h"

DisplayShield::DisplayShield(int ld, int cd, int dd) {
    LATCH_DIO = ld;//4
    CLK_DIO = cd;//7
    DATA_DIO = dd;//8
    pinMode(LATCH_DIO,OUTPUT);
    pinMode(CLK_DIO,OUTPUT);
    pinMode(DATA_DIO,OUTPUT);
	//Serial.println("aqui"); OK
}

void DisplayShield::WriteNumberToSegment(byte Segment, byte Value) {
  digitalWrite(LATCH_DIO,LOW);
  shiftOut(DATA_DIO, CLK_DIO, MSBFIRST, SEGMENT_MAP[Value]);
  shiftOut(DATA_DIO, CLK_DIO, MSBFIRST, SEGMENT_SELECT[Segment] );
  digitalWrite(LATCH_DIO,HIGH);
}

void DisplayShield::WriteBigNum(int n){
  int i=3;
  while(i>-1){
    WriteNumberToSegment(i-- , n%10);
    n=n/10;
  }
}

void DisplayShield::WriteLetterToSegment(byte Segment, char c){
  digitalWrite(LATCH_DIO,LOW);
  shiftOut(DATA_DIO, CLK_DIO, MSBFIRST, SEGMENT_MAP_ALPHA[c - 65]);
  shiftOut(DATA_DIO, CLK_DIO, MSBFIRST, SEGMENT_SELECT[Segment] );
  digitalWrite(LATCH_DIO,HIGH);
}
